const { ActivityType } = require('discord.js');
const registerWarnCommand = require('../../SlashCommands/SlashCommand');
module.exports = (client, chalk) => {
    client.on('clientReady', async () => {
        console.log(chalk.yellow(`${client.user.tag} is ready`));
        client.user.setPresence({
            status: 'idle',
            activities: [{
                name: 'https://discord.gg/6jUBXvpU36',
                type: ActivityType.Watching
            }]
        });
    });
}
