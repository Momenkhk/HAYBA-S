module.exports = {
    Spin: {
        Basic: {
            WinLog: '', 
            Prizes: [
                'off',
                'off',
                'off',
                'off',
                'off'
            ]
        },
        Exclusive: {
            WinLog: '', 
            Prizes: [
                'off',
                'off',
                'off',
                'off',
                'off'
            ]
        }
    }
};
