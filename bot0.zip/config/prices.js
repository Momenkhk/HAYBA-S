module.exports = {
    Posts: {
        here: 45000,
        every: 80000,
    },

    ads: {
        'بدون منشن': '50000',
        'منشن هير': '100000',
        'منشن ايفري ون': '150000',
        'بروم الهداية': '500000',
        'روم خاص مع قيف اوي': '5000000',
        'اول روم': '9000000',
    },

    PrivteRoom: {
        Day7: 140000
    },
    Spin:
    {
        Basic: false,
        Exclusive: false
    },
    Mzad: {
        mzad: false
    },
    RemoveWarns: {
        W25: 25000,
        W50: 25000
    },
    Transfer: {
        transfer: 35000
    },
}
